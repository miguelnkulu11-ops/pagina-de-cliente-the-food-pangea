---
name: Warm Culinary E-Commerce
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0eded'
  surface-container-high: '#eae7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1c1b1b'
  on-surface-variant: '#59413a'
  inverse-surface: '#313030'
  inverse-on-surface: '#f3f0ef'
  outline: '#8d7168'
  outline-variant: '#e1bfb5'
  surface-tint: '#ab3504'
  primary: '#a83301'
  on-primary: '#ffffff'
  primary-container: '#ca4a1c'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb59d'
  secondary: '#715d00'
  on-secondary: '#ffffff'
  secondary-container: '#fed41c'
  on-secondary-container: '#705b00'
  tertiary: '#00628d'
  on-tertiary: '#ffffff'
  tertiary-container: '#007cb1'
  on-tertiary-container: '#fcfcff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbd0'
  primary-fixed-dim: '#ffb59d'
  on-primary-fixed: '#390b00'
  on-primary-fixed-variant: '#842500'
  secondary-fixed: '#ffe178'
  secondary-fixed-dim: '#ebc300'
  on-secondary-fixed: '#231b00'
  on-secondary-fixed-variant: '#554500'
  tertiary-fixed: '#c8e6ff'
  tertiary-fixed-dim: '#88ceff'
  on-tertiary-fixed: '#001e2f'
  on-tertiary-fixed-variant: '#004c6e'
  background: '#fcf9f8'
  on-background: '#1c1b1b'
  surface-variant: '#e5e2e1'
  brand-orange: '#E05A2B'
  brand-crimson: '#D13D16'
  brand-sun: '#FCD219'
  neutral-dark: '#1A1A1A'
  surface-muted: '#F9F8F6'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  margin: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 3rem
---

## Brand & Style
This design system embraces a modern, warm culinary aesthetic tailored for high-end restaurant e-commerce. The brand personality is inviting, energetic, and sophisticated, striking a balance between approachable hospitality and sleek digital efficiency. 

We utilize a **Modern Minimalist** design style characterized by generous whitespace, high-contrast typography, and vibrant chromatic accents that evoke appetite and urgency. Visual hierarchy is established through intentional scale and surface layering rather than heavy ornamentation, ensuring the culinary photography remains the hero of the interface.

## Colors
The color palette is built around a vibrant, appetite-stimulating orange primary (`#E05A2B`), complemented by a rich secondary golden yellow (`#FCD219`) for highlights and status indicators. 

- **Primary (`#E05A2B`):** Drives primary actions, active states, key interactive elements, and brand touchpoints.
- **Secondary (`#FCD219`):** Used sparingly for badges, ratings, and promotional accents.
- **Neutrals:** Crisp dark neutral (`#1A1A1A`) ensures maximum legibility for typography, paired with a warm off-white surface tint (`#F9F8F6`) to maintain a cozy, premium dining atmosphere.

## Typography
Typography is clean, highly legible, and neutral, allowing menu items and pricing to command immediate attention. We rely on **Inter** for its exceptional rendering across multi-language support (including Latin, Arabic, and Cyrillic character sets required for global culinary platforms).

- **Scale:** Headings utilize tight tracking (`-0.02em`) for a modern editorial feel, while body text prioritizes open aperture and high x-height for rapid scanning.
- **Responsive adjustments:** Large desktop headlines scale down gracefully on mobile viewports to prevent awkward wrapping.

## Layout & Spacing
This design system uses a **fluid 12-column grid** paired with generous whitespace to create an airy, premium browsing experience. 

- **Gutters & Margins:** Fluid gutters (`1.5rem`) maintain comfortable separation between menu cards, while outer canvas margins scale from `1rem` on mobile to `3rem` on desktop.
- **Rhythm:** Spacing follows an 8px base unit scale, ensuring consistent vertical rhythm across product listings, category filters, and checkout flows.

## Elevation & Depth
Elevation is handled through **tonal layers and ambient shadows** that simulate a tactile, high-end paper menu feel. 

- **Surfaces:** Cards and interactive drawers sit on elevated white surfaces against the warm neutral background (`#F9F8F6`).
- **Shadows:** Ambient shadows are soft, multi-layered, and tinted with low-opacity warm undertones (`rgba(224, 90, 43, 0.08)`) to maintain warmth rather than cold corporate neutrality. Floating elements like the cart drawer use higher elevation tiers (`z-index` stacking with deep backdrop blurs).

## Shapes
A **rounded shape language** (`roundedness: 2`, featuring `0.5rem` base radii and `1rem` for large containers) communicates approachability, friendliness, and modern hospitality. 

- **Interactive Elements:** Buttons, chips, input fields, and food cards use soft, continuous curves to feel tactile and clickable.
- **Badges & Pills:** Dietary tags and category filters use fully rounded pill shapes (`9999px`) for quick visual parsing.

## Components
Consistent UI components ensure a seamless ordering experience from browsing to checkout.

- **Buttons:** Primary action buttons feature the brand orange fill (`#E05A2B`) with crisp white text, generous horizontal padding, and subtle active scale-down states. Secondary buttons use transparent backgrounds with a clean border stroke.
- **Chips & Filters:** Category selectors use horizontal scrolling pill chips with active states swapping to the primary brand color.
- **Input Fields:** Form inputs for delivery addresses and checkout details feature soft rounded borders, clear floating labels, and inline validation states.
- **Cards:** Menu item cards showcase edge-to-edge photography, clear typographic hierarchy for dish titles and descriptions, and a floating quick-add action button.
- **Cart Drawers:** Smooth slide-over panels featuring sticky subtotal summaries, item customization modifiers, and multi-language currency switchers.
- **Checkboxes & Radios:** Custom-styled indicators utilizing the primary accent color for selected states to reinforce brand cohesion.